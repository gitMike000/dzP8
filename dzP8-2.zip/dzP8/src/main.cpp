﻿#include "include/SBomber.h"
#include "include/MyTools.h"
#include "include/ScreenSingleton.h"

#include <iostream>
#include <fstream>

#include "include/kbd.h"

int main(void)
{
    MyTools::FileLoggerSingletone::getInstance().OpenLogFile("log.txt");

    SBomber game;

    do
    {
        game.TimeStart();

        if (_kbhit())
        {
            game.ProcessKBHit();
        }

        ScreenSingleton::getInstance().ClrScr();

        game.DrawFrame();
        game.MoveObjects();
        game.CheckObjects();

        game.TimeFinish();

    } while (!game.GetExitFlag());

    MyTools::FileLoggerSingletone::getInstance().CloseLogFile();

    game.AnimateScrolling(); // Вызов анимированного скроллинга

    return 0;
}
