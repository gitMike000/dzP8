#include "include/Bomb.h"
#include <iostream>
#include "include/ScreenSingleton.h"

void Bomb::Draw() const {
  //ScreenSingleton::getInstance().SetColor(CC_LightMagenta);
  ScreenSingleton::getInstance().GotoXY(x, y);
  std::cout << "*";
}

Bomb* Bomb::Clone() const {
    return new Bomb(*this);
};
